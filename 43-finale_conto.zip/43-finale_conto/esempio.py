from datetime import datetime
class Intestatario:
  numero_intestatari=0
  def __init__(self, nome, cognome, data):
     self.nome=nome
     self.cognome=cognome
     Intestatario.numero_intestatari+=1
     if self.__data_valida(data):
        self.data=data
     else:
        raise TypeError("Data non valida")
     self.id=Intestatario.numero_intestatari
	 
  def __data_valida(self, data):
     return isinstance(data, datetime) and (datetime.now()-data).days/365>=18

  @property
  def eta(self):
     eta=int((datetime.now()-self.data).days/365)
     return eta

  def __str__(self):
     return f"{self.cognome} {self.nome}, anni {self.eta} (id: {self.id})"


class Conto:
  contatore=1000
  
  def __init__(self, *intestatari):
     self.intestatari=intestatari
     self.importi=[]
     self.numero=self.__genera_numero()

  def __genera_numero(self):
     Conto.contatore+=1
     return Conto.contatore

  def nuovo_importo(self, *importo):
     for x in importo:
        self.importi.append(x)

  def calcola_saldo(self):
     return sum(self.importi)

  def __str__(self):
     return f"Conto n. {self.numero} di n. {len(self.intestatari)}, saldo={self.calcola_saldo()}"

i1=Intestatario("Luigi", "Rossi", datetime(1948, 3, 25))
i2=Intestatario("Elena", "Bianchi", datetime(1956, 7, 1))
i3=Intestatario("Nicola", "Rossi", datetime(1983, 4, 10))

c1=Conto(i1, i2)
c2=Conto(i3)
c3=Conto(i1,i2,i3)

c1.nuovo_importo(500, 700, -600, 3000, -400)
c2.nuovo_importo(1200, 400, -100, -500, -850)
c3.nuovo_importo(500, 400, -100, 250)

print(c1)
print(c2)
print(c3)






	  