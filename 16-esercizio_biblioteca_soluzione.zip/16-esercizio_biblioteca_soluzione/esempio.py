class Libro:
   def __init__(self,titolo,autore,genere):
       self.titolo=titolo
       self.autore=autore
       self.genere=genere
	   
   def __str__(self):
       return f'"{self.titolo}" di {self.autore} ({self.genere})'
	   
class Biblioteca:
   def __init__(self):
       self.catalogo=[]
       self.generi=dict()

   def aggiungi_libro(self, libro):
       self.catalogo.append(libro)
       if libro.genere not in self.generi:
          self.generi[libro.genere]=[]
       self.generi[libro.genere].append(libro)

   def stampa_per_generi(self):
       for genere in self.generi:
          print(f'--- Categoria "{genere}"')
          for libro in self.generi[genere]:
             print(f'  {libro}')

biblio=Biblioteca()
l1=Libro("Omicidio al molo", "Enrico Rossi", "giallo")
l2=Libro("Guida a Python", "Silvio Bianchi", "informatica")
l3=Libro("Il giardino perfetto", "Alessia Versi", "manuali")
l4=Libro("Il complotto", "Enrico Rossi", "giallo")
l5=Libro("Java per esempi", "Andrea Marroni", "informatica")

biblio.aggiungi_libro(l1)
biblio.aggiungi_libro(l2)
biblio.aggiungi_libro(l3)
biblio.aggiungi_libro(l4)
biblio.aggiungi_libro(l5)

biblio.stampa_per_generi()

print()

print(biblio.catalogo[3])

print()
l1.titolo="Omicidio al molo Parte II"

print(l1)
print(biblio.catalogo[0])
print(biblio.generi['giallo'][0])

   	   
   
