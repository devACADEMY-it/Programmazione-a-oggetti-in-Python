class Libro:
   def __init__(self, titolo, autore):
      self._titolo=titolo
      self._autore=autore

   @property
   def titolo(self):
      return self._titolo

   @titolo.setter
   def titolo(self, valore):
      self._titolo=valore

   @property
   def autore(self):
      return self._autore   

   @autore.setter
   def autore(self, autore):
      self._autore=autore
	  