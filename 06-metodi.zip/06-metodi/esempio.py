class Studente:
   def __init__(self,nome,cognome,eta):
      self.nome=nome
      self.cognome=cognome
      self.eta=eta

   def media_finale(self, media):
      self.media=media

   def valuta_promozione(self):
      return self.media>=6