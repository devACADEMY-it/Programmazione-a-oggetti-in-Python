class Studente:
   def __init__(self,nome,cognome,eta):
      self.nome=nome
      self.cognome=cognome
      self.eta=eta

   def imposta_media_finale(self, media):
      self._media=media
	  
   def leggi_media_finale(self):
      return self._media
	  
   def valuta_promozione(self):
      return self.media>=6

   promosso=property(valuta_promozione)
   media=property(leggi_media_finale, imposta_media_finale)
   
nuovo_studente=Studente("Enrico", "Gialli", 24)
nuovo_studente.media=7.5
print(f'La media di {nuovo_studente.cognome} è {nuovo_studente.media}')

if nuovo_studente.promosso:
  print(f'{nuovo_studente.nome} {nuovo_studente.cognome} è promosso')
else:
  print(f'{nuovo_studente.nome} {nuovo_studente.cognome} è bocciato')