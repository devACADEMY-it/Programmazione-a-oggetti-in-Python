class Studente:
    def __init__(self, nome, cognome):
      self.nome=nome
      self.cognome=cognome