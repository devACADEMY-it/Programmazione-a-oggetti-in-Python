class Persona:
   def __init__(self,nome,cognome,eta):
      self.nome=nome
      self.cognome=cognome
      self.eta=eta

   def maggiorenne(self):
      return self.eta>=18
	  
class Studente(Persona):
   def __init__(self,nome,cognome,eta):
      Persona.__init__(self,nome,cognome,eta)
      self.voti=[]

   def nuovo_voto(self, voto):
      if 0<=voto<=10:
         self.voti.append(voto)
      else:
         print(f'{voto} non incluso nel range di voti validi (0-10)')

   def calcola_media_finale(self):
      if len(self.voti)<1:
         return -1
      return round(sum(self.voti)/len(self.voti), 1)

   def valuta_promozione(self):
      return self.media>=6

   def __str__(self):
      return f"{self.nome} {self.cognome} ha conseguito la media del {self.media}"

   promosso=property(valuta_promozione)
   media=property(calcola_media_finale)
   
class Docente(Persona):
   def __init__(self,nome,cognome,laurea,eta):
      Persona.__init__(self,nome,cognome,eta)
      self.laurea=laurea

   def __str__(self):
      return f"Prof. {self.nome} {self.cognome}, laureato in {self.laurea}"

class Corso:
   def __init__(self, nome, docente, allievi):
      self.nome=nome
      self.docente=docente
      self.allievi=allievi
      self.__crea_id()
	  
   def __crea_id(self):
      from random import randrange
      self.id=self.nome[:3].upper()+str(randrange(1000,10000))

   def nuovo_allievo(self, allievo):
      self.allievi.append(allievo)

   def __str__(self):
      return f"Corso di {self.nome}\n Docente: {self.docente}\n Numero allievi: {len(self.allievi)}"

class Centro_formazione:
   def __init__(self):
      self.corsi=dict()

   def nuovo_corso(self, corso):
      if corso.id in self.corsi:
         print("Errore, esiste già un corso con identificativo "+corso.id)
      else:
         self.corsi[corso.id]=corso

   def numero_corsi(self):
      return len(self.corsi)


	  
docente1=Docente("Enrico", "Bianchi", "Lettere", 45)
a1=Studente("Marta","Neri", 21)
a2=Studente("Marco","Rossi", 22)
a3=Studente("Ivan","Gialli", 21)

corso1=Corso("Storia moderna", docente1, [a1, a2, a3])

a4=Studente("Ilenia","Azzurri", 20)
a5=Studente("Davide", "Verdi", 23)
docente2=Docente("Maria", "Marroni", "Lettere", 38)

corso2=Corso("Geografia", docente2, [a1, a2, a3, a4, a5])

corso3=Corso("Storia antica", docente1, [a3, a5])

centro=Centro_formazione()
centro.nuovo_corso(corso1)
centro.nuovo_corso(corso2)
centro.nuovo_corso(corso3)

print(f"Il centro ha attualmente {centro.numero_corsi()} corsi")

for codice, corso in centro.corsi.items():
   print(codice)
   print(corso)
   





