class Libro:
   numero=0
   def __init__(self, titolo, autore):
      self.titolo=titolo
      self.autore=autore
      Libro.numero+=1

   @classmethod
   def totale_libri(cls):
      return cls.numero

   @staticmethod
   def info():
      return "Classe che serve a definire libri"