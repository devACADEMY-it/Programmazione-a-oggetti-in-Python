def maiuscolo(function):
   def decorazione():
      stringa=function()
      return stringa.upper()
   return decorazione

@maiuscolo
def genera_stringa():
   return "pizza"
   
def genera_stringa_2():
   return "pizza"


print(genera_stringa())
print(genera_stringa_2())
   