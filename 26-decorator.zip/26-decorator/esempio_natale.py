def natalizio(function):
   def decorazione():
      stringa=function()
      lunghezza=len(stringa)
      return f"{'*'*(lunghezza+6)}\n** {stringa} **\n{'*'*(lunghezza+6)}"
   return decorazione

def genera_stringa():
   return "Auguri"
   
@natalizio
def genera_stringa_2():
   return "pizza"

print(genera_stringa())
print(genera_stringa_2())