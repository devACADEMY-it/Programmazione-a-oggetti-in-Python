def valuta_maggiore_eta(eta):
   if eta<0:
      raise ValueError(f"Valore non valido: {eta}")
   return eta>=18

eta=20
try:
   if valuta_maggiore_eta(eta):
      print("La persona è maggiorenne")
   else:
      print("La persona è minorenne")
except ValueError as v:
   print(f"Inviato valore non valido ({v})")
   