class Studente:
   def __init__(self,nome,cognome,eta):
      self.nome=nome
      self.cognome=cognome
      self.eta=eta
	  
s1=Studente("Gianluca","Rossi", 22)
s2=Studente("Vanessa","Bianchi", 22)

if s1.eta==s2.eta:
   print(f'{s1.nome} e {s2.nome} sono coetanei')
else:
   print(f'{s1.nome} e {s2.nome} NON sono coetanei')