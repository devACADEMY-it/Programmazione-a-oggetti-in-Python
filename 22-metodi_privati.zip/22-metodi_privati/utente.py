from random import choice

class Utente:
  def __init__(self, username):
     self.username=username
     self.recapiti=[]
     self.__imposta_password()

  def __imposta_password(self):
     self.password=str(choice(range(11111, 55555)))

  def aggiungi_recapito(self, recapito):
     self.recapiti.append(recapito)
  