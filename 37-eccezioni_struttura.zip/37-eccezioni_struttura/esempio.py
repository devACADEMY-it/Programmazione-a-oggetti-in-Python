lista=[1,2,3,4,5,6]
try:
     lista[0]=15/0
     print(f"Assegnazione riuscita: {lista}")
except ZeroDivisionError:
     print("Errore: divisione per zero")
except IndexError:
     print("Errore: posizione non valida")
except:
     print("Errore generico")
else:
     print("Tutto senza eccezioni")
finally:
     print("Scatta SEMPRE")
print("Fine programma!")