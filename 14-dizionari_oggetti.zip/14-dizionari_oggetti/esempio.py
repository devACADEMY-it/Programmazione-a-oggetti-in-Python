class Studente:
   def __init__(self, nome, cognome, matricola):
      self.nome=nome
      self.cognome=cognome
      self.matricola=matricola
      self.voti=[]

   def nuovo_voto(self, voto):
      if 0<=voto<=10:
         self.voti.append(voto)
      else:
         print(f'{voto} non incluso nel range di voti valido (0-10)')

   def calcola_media_finale(self):
      if len(self.voti)<1:
         return -1
      return round(sum(self.voti)/len(self.voti), 1)

   def valuta_promozione(self):
      return self.media>=6

   def __str__(self):
      return f"{self.nome} {self.cognome} ha conseguito la media del {self.media}"

   promosso=property(valuta_promozione)
   media=property(calcola_media_finale)
   
s1=Studente("Enea","Rossi", "S12345")
s2=Studente("Alessia","Bianchi", "S99977")
s3=Studente("Marina","Verdi", "S54321")

s1.nuovo_voto(8)
s1.nuovo_voto(5)

s2.nuovo_voto(9)
s2.nuovo_voto(8)

s3.nuovo_voto(7)
s3.nuovo_voto(7)

corso=dict()
corso[s1.matricola]=s1
corso[s2.matricola]=s2
corso[s3.matricola]=s3

print(corso["S12345"].cognome)

print("\nStampa per chiavi\n")

for chiave in corso:
   print(chiave)
   
print("\nStampa per valori\n")

for allievo in corso.values():
   print(allievo)
   
print("\nStampa per chiave/valore\n")

for chiave, valore in corso.items():
   print(f"{chiave}: {valore}")
   
