class Studente:
   def __init__(self,nome,cognome,eta):
      self.nome=nome
      self.cognome=cognome
      self.eta=eta
      self.voti=[]

   def nuovo_voto(self, voto):
      if 0<=voto<=10:
         self.voti.append(voto)
      else:
         print(f'{voto} non incluso nel range di voti validi (0-10)')

   def calcola_media_finale(self):
      if len(self.voti)<1:
         return -1
      return round(sum(self.voti)/len(self.voti), 1)

   def valuta_promozione(self):
      return self.media>=6

   def __str__(self):
      return f"{self.nome} {self.cognome} ha conseguito la media del {self.media}"

   promosso=property(valuta_promozione)
   media=property(calcola_media_finale)
   
allievo=Studente("Enrico", "Gialli", 24)
allievo.nuovo_voto(6)
allievo.nuovo_voto(8)
allievo.nuovo_voto(8)

print(allievo)