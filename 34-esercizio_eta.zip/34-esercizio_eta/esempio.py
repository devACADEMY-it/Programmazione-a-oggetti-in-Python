from datetime import datetime
class Persona:
   def __init__(self,nome,cognome,data):
      self.nome=nome
      self.cognome=cognome
      self.data=data

   @property
   def eta(self):
      eta=int((datetime.now()-self.data).days/365)
      return eta

   @property
   def maggiorenne(self):
      return self.eta>=18