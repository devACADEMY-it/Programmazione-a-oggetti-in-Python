class Persona:
   def __init__(self,nome,cognome,eta):
      self.nome=nome
      self.cognome=cognome
      self.eta=eta

   def maggiorenne(self):
      return self.eta>=18
	  
class Studente(Persona):
   def __init__(self,nome,cognome,eta):
      Persona.__init__(self,nome,cognome,eta)
      self.voti=[]

   def nuovo_voto(self, voto):
      if 0<=voto<=10:
         self.voti.append(voto)
      else:
         print(f'{voto} non incluso nel range di voti validi (0-10)')

   def calcola_media_finale(self):
      if len(self.voti)<1:
         return -1
      return round(sum(self.voti)/len(self.voti), 1)

   def valuta_promozione(self):
      return self.media>=6

   def __str__(self):
      return f"{self.nome} {self.cognome} ha conseguito la media del {self.media}"

   promosso=property(valuta_promozione)
   media=property(calcola_media_finale)
   
class Docente(Persona):
   def __init__(self,nome,cognome,laurea,eta):
      Persona.__init__(self,nome,cognome,eta)
      self.laurea=laurea

   def __str__(self):
      return f"Prof. {self.nome} {self.cognome}, laureato in {self.laurea}"

class Corso:
   def __init__(self, nome, docente, allievi):
      self.nome=nome
      self.docente=docente
      self.allievi=allievi

   def nuovo_allievo(self, allievo):
      self.allievi.append(allievo)

   def __str__(self):
      return f"Corso di {self.nome}\n Docente: {self.docente}\n Numero allievi: {len(self.allievi)}"

docente=Docente("Enrico", "Bianchi", "Lettere", 45)
a1=Studente("Marta","Neri", 21)
a2=Studente("Marco","Rossi", 22)
a3=Studente("Ivan","Gialli", 21)

corso=Corso("Storia moderna", docente, [a1, a2, a3])

a4=Studente("Ilenia","Azzurri", 20)
corso.nuovo_allievo(a4)

print(corso)