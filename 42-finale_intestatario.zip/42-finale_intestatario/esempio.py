from datetime import datetime
class Intestatario:
  numero_intestatari=0
  def __init__(self, nome, cognome, data):
     self.nome=nome
     self.cognome=cognome
     Intestatario.numero_intestatari+=1
     if self.__data_valida(data):
        self.data=data
     else:
        raise TypeError("Data non valida")
     self.id=Intestatario.numero_intestatari
	 
  def __data_valida(self, data):
     return isinstance(data, datetime) and (datetime.now()-data).days/365>=18

  @property
  def eta(self):
     eta=int((datetime.now()-self.data).days/365)
     return eta

  def __str__(self):
     return f"{self.cognome} {self.nome}, anni {self.eta} (id: {self.id})"


i1=Intestatario("Luigi", "Rossi", datetime(1948, 3, 25))
i2=Intestatario("Elena", "Bianchi", datetime(1956, 7, 1))
i3=Intestatario("Nicola", "Rossi", datetime(1983, 4, 10))

print(i1)
print(i2)
print(i3)











	  