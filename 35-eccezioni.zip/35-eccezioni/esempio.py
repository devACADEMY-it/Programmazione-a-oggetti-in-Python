try:
   y=10/3
   print(y)
except:
   print("Errore")
print("Fine programma")