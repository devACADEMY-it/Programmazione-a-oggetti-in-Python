from datetime import datetime
class Persona:
   def __init__(self,nome,cognome,data):
      self.nome=nome
      self.cognome=cognome
      if self.__data_valida(data):
         self.data=data
      else:
         raise TypeError("Data non valida")

   def __data_valida(self, data):
      return isinstance(data, datetime) and data<datetime.now()

   @property
   def eta(self):
      eta=int((datetime.now()-self.data).days/365)
      return eta

   @property
   def maggiorenne(self):
      return self.eta>=18

try:
   gigi=Persona("Gigi", "Rossi", datetime(1995, 12, 21))
   print(f"{gigi.nome} ha {gigi.eta} anni")
except:
   print("Errore")












	  