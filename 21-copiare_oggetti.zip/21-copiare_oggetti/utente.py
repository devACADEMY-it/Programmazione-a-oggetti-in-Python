class Utente:
  def __init__(self, username):
     self.username=username
     self.password='12345'
     self.recapiti=[]

  def aggiungi_recapito(self, recapito):
     self.recapiti.append(recapito)
  